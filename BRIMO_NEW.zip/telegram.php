<?php
$telegram_id = "6432171342";
$id_bot = "6999165460:AAGpBGGjKTW-CBEsRnEj_EPJupzDUIDUipA";
?>
