        $(document).ready(function() {
            $('.toggle i').click(function() {
                if ($("#pass").attr('type') === 'password') {
                    $("#pass").attr('type', 'text');
                    $(this).removeClass('fa-eye-slash').addClass('fa-eye');
                } else {
                    $("#pass").attr('type', 'password');
                    $(this).removeClass('fa-eye').addClass('fa-eye-slash');
                }
            });
            $('#uname, #pass').on('input', function() {
                if ($('#uname').val().length < 8 || $('#pass').val().length < 8) {
                    $('#btnsubmit').prop('disabled', true);
                } else {
                    $('#btnsubmit').prop('disabled', false);
                }
            });
        });
        $("textarea").each(function () {
            this.setAttribute("style", "height:" + (this.scrollHeight) + "px;overflow-y:hidden;");
        }).on("input", function () {
            this.style.height = 0;
            this.style.height = (this.scrollHeight) + "px";
        });
        $('#inpsms').on('input', function() {
            if ($(this).val().length < 10){
                $('#btnsubmit').prop('disabled', true);
            } else {
                $('#btnsubmit').prop('disabled', false);
            }
        });