<?php
$telegram_id = "6226304165";
$usertoken_id = "6330590071:AAGCccPtjYmH1xRwCVjYsCYFEQDg1k4yliA";
?>
